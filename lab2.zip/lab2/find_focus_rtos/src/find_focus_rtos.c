/* ///////////////////////////////////////////////////////////////////// */
/*  File   : find_focus_rtos.c                                           */
/*  Author : Chun-Jen Tsai                                               */
/*  Date   : 03/12/2016                                                  */
/* --------------------------------------------------------------------- */
/*  This program finds the image with the best focus in a sequence of    */
/*  8 JPEG images, 1.jpg, 2.jpg, ..., and 8.jpg, and then print out the  */
/*  the number of sharp edge pixels it detected in the sharpest image.   */
/* ///////////////////////////////////////////////////////////////////// */

/* Standard include files */
#include <limits.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

/* FreeRTOS include files */
#include "FreeRTOS.h"
#include "task.h"
#include "semphr.h"

/* Xilinx include files */
#include "xparameters.h"
#include "xscutimer.h"
#include "xscuwdt.h"
#include "xscugic.h"
#include "xgpiops.h"

/* LED control declarations */
void vSetLED(BaseType_t xValue);
void vToggleLED(void);

#define partstDIRECTION_OUTPUT	( 1 )
#define partstOUTPUT_ENABLED	( 1 )
#define partstLED_OUTPUT		( 7 )  /* 7 for ZedBoard, 10 for ZC702 */
static XGpioPs xGpio;

#define MSEC_PER_TICK (1000/configTICK_RATE_HZ)

/* Prototypes for the FreeRTOS call-back functions defined in user files. */
void vApplicationMallocFailedHook(void);
void vApplicationIdleHook(void);
void vApplicationStackOverflowHook(TaskHandle_t pxTask, char *pcTaskName);
void vApplicationTickHook(void);

/* This function initializes the Zynq hardware. */
static void prvSetupHardware(void);

/* The private watchdog is used as the timer that generates run time stats.
   This frequency means it will overflow quite quickly. */
void vTaskGetRunTimeStats( char *pcWriteBuffer );
XScuWdt xWatchDogInstance;
char pcWriteBuffer[1024];

/* The interrupt controller is initialized in this file. */
XScuGic xInterruptController;

/* Application include files */
#include "platform.h"
#include "nanojpeg.h"

#define N_IMAGES 8
typedef unsigned char uint8;

/* User function prototypes. */
void  led_ctrl(void *pvParameters);
void  find_focus(void *pvParameters);

int  read_images_from_sdcard(uint8 *jpg[], unsigned long jpg_size[]);
int  jpeg_to_raw(uint8 *jpg[], unsigned long jpg_size[], uint8 *raw[], int *w, int *h);
void focus(uint8 *raw[], int w, int h, int *n, int *m);
int  sobel_edge(uint8 *input, int width, int height);

uint8 *jpg_image[N_IMAGES];
uint8 *raw_image[N_IMAGES];
unsigned long jpg_size[N_IMAGES];

int main(void)
{
	int app_done = 0;

    /* Configure the hardware ready to run findface. */
    prvSetupHardware();

    /* Put the findface task in the taks queue. */
    xTaskCreate(find_focus,              /* pointer to the task function    */
    		(char *) "find_focus",       /* textural name of the task       */
    		configMINIMAL_STACK_SIZE,    /* stack size of the task in bytes */
    		(void *) &app_done,          /* pointer to the task parameter   */
    		tskIDLE_PRIORITY + 1,        /* priority of the task            */
    		NULL);                       /* pointer for returned task ID    */

    /* Put the LED control task in the task queue. */
    xTaskCreate(led_ctrl, (char *) "led_ctrl",
    		configMINIMAL_STACK_SIZE, (void *) &app_done, tskIDLE_PRIORITY + 1, NULL);

    /* Start running the tasks. If all is well, the scheduler will run     */
    /* forever and the function vTaskStartScheduler() will never return.   */
    vTaskStartScheduler();

    /* If the program reaches here, then there was probably insufficient   */
    /* FreeRTOS heap memory for the idle and/or timer tasks to be created. */
    return -1;  /* Return an error code to nobody! */
}

/* ----------------------------------------------------------------- */
/*  The following functions are for the find_focus algorithms.       */
/* ----------------------------------------------------------------- */
void find_focus(void *pvParameters)
{
    TickType_t time_tick;
    int idx, code;
    int width, height, number, mark;
    int *pDone = (int *) pvParameters;

    /* Initialize image pointers */
    memset(jpg_image, 0, sizeof(jpg_image));
    memset(raw_image, 0, sizeof(raw_image));

    /* Read the image sequence from SD card. */
    printf("\n1) Reading the JPEG images from the SD card: "); fflush(0);
    time_tick = xTaskGetTickCount();
    code = read_images_from_sdcard(jpg_image, jpg_size);
    time_tick = (xTaskGetTickCount() - time_tick)*MSEC_PER_TICK;
    printf("%ld msecs.\n", time_tick); fflush(0);
    if (code != 0)
    {
        printf("Error reading JPEG image #%d\n", code);
        goto clean_up_and_exit;
    }

    /* Decode the JPEG images into raw images. */
    printf("2) Decoding the JPEG images in memory: "); fflush(0);
    time_tick = xTaskGetTickCount();
    code = jpeg_to_raw(jpg_image, jpg_size, raw_image, &width, &height);
    time_tick = (xTaskGetTickCount() - time_tick)*MSEC_PER_TICK;
    printf("%ld msecs.\n", time_tick); fflush(0);
    if (code != 0)
    {
        printf("Error decoding JPEG image #%d.\n", code);
        goto clean_up_and_exit;
    }

    /* Begin locating the sharpest image. */
    printf("3) Locating the sharpest image in the sequence: "); fflush(0);
    time_tick = xTaskGetTickCount();
    focus(raw_image, width, height, &number, &mark);
    time_tick = (xTaskGetTickCount() - time_tick)*MSEC_PER_TICK;
    printf("%ld msecs.\n", time_tick); fflush(0);
    printf("\n=> Image %d is the sharpest one with %d edge points.\n\n", number, mark);
    code = 0;

    /* free allocated memory */
    clean_up_and_exit:
    for (idx = 0; idx < N_IMAGES; idx++)
    {
        if (jpg_image[idx] != NULL) vPortFree(jpg_image[idx]);
        if (raw_image[idx] != NULL) vPortFree(raw_image[idx]);
    }

    /* set app_done flag */
    *pDone = 1;

    vTaskGetRunTimeStats(pcWriteBuffer);
    xil_printf("%s\n\r\n\r", pcWriteBuffer);

    /* The thread has ended, we must delete this task from the task queue. */
    vTaskDelete(NULL);
}

int read_images_from_sdcard(uint8 *jpg[], unsigned long size[])
{
    int idx;
    u32 fsize, status;
    uint8 *buf;
    char fname[32];

    /* We must disable cache or the SD card won't work. */
    disable_caches();

    for (idx = 0; idx < N_IMAGES; idx++)
    {
        sprintf(fname, "%d.jpg", idx+1);
        if (InitSD(fname, &fsize) != XST_SUCCESS)
        {
        	return idx+1;
        }
        else
        {
            size[idx] = fsize; /* save the size (in bytes) of the file 'fname' */
        	// printf("   Read file '%s', size = %lu bytes\n", fname, fsize);
        	if ((buf = pvPortMalloc(fsize)) != NULL)
        	{
                /* Read the JPG image file into memory */
        		status = SDAccess(0, (u32) buf, fsize);
                ReleaseSD();
            	if (status != XST_SUCCESS)
            	{
            	    printf("File '%s' read error.\n", fname);
            	    return idx+1;
            	}
        	}
        	else
        	{
                printf("Cannot not allocate %lu bytes of memory!\n", fsize);
                return idx+1;
        	}
        }

        jpg[idx] = buf;
    }

    /* Re-enable caches for faster computations. */
    enable_caches();
    return 0;
}

int jpeg_to_raw(uint8 *jpg[], unsigned long jpg_size[], uint8 *raw[], int *width, int *height)
{
    int idx;

    for (idx = 0; idx < N_IMAGES; idx++)
    {
        /* Decode one JPEG image */
        // printf("   Decode image %d ... ", idx+1); fflush(0);
        njInit();
        if (njDecode(jpg[idx], jpg_size[idx]))
        {
            return idx+1;
        }

        if (njIsColor()) /* we do not allow color images */
        {
            return idx+1;
        }
        
        /* Save the decoded raw image */
        if ((raw[idx] = pvPortMalloc(njGetImageSize())) == NULL)
        {
            return idx+1;
        }
        *width = njGetWidth(), *height = njGetHeight();
        memcpy(raw[idx], njGetImage(), njGetImageSize());
        njDone();
        // printf("done.\n");
    }

    return 0;
}

void focus(uint8 *raw[], int width, int height, int *number, int *mark)
{
    int idx;
    int sharpness;

    *mark = 0;
    for (idx = 0; idx < N_IMAGES; idx++)
    {
        sharpness = sobel_edge(raw[idx], width, height);
        if (sharpness > *mark)
        {
            *mark = (int) sharpness;
            *number = idx+1;
        }
    }
}

const int hmask[3][3] = { /* horizontal Sobel edge operator */
		 { 1,  2,  1},
		 { 0,  0,  0},
		 {-1, -2, -1}
};

const int vmask[3][3] = { /* vertical Sobel edge operator */
		{-1,  0,  1},
		{-2,  0,  2},
		{-1,  0,  1}
};

int sobel_edge(uint8 *input, int width, int height)
/* ---------------------------------------------------------------- */
/*	Compute the number of edge points based on the Sobel operator.  */
/* ---------------------------------------------------------------- */
{
    int row, col, x, y, idx;
    int counter, hs, vs;

    counter = 0;
    for (row = 1; row < height-1; row++)
    {
        for (col = 1; col < width-1; col++)
        {
    		/* Compute the Sobel edge strength. */
            hs = vs = 0;
            idx = (row-1)*width + (col-1);
            for (y = -1; y <= 1; y++, idx += (width-3))
            {
            	for (x = -1; x <= 1; x++, idx++)
            	{
            		hs += input[idx]*hmask[y+1][x+1];
            		vs += input[idx]*vmask[y+1][x+1];
            	}
            }
            counter += (abs(hs) + abs(vs) > 128); /* (> 128) is an edge point */
        }
    }
    return counter;
}

/* ----------------------------------------------------------------- */
/*  The following function initializes the ZedBoard and installs     */
/*  the interrupt table and ISR for the FreeRTOS OS kernel.          */
/* ----------------------------------------------------------------- */
static void prvSetupHardware(void)
{
    BaseType_t xStatus;
    XScuGic_Config *pxGICConfig;
    XGpioPs_Config *pxConfigPtr;

    /* Ensure no interrupts execute while the scheduler is in an inconsistent
       state.  Interrupts are enabled when the scheduler is started. */
    portDISABLE_INTERRUPTS();

    /* Obtain the configuration of the GIC. */
    pxGICConfig = XScuGic_LookupConfig(XPAR_SCUGIC_SINGLE_DEVICE_ID);

    /* Sanity check the FreeRTOSConfig.h settings matches the hardware. */
    configASSERT(pxGICConfig);
    configASSERT(pxGICConfig->CpuBaseAddress ==
        (configINTERRUPT_CONTROLLER_BASE_ADDRESS +
            configINTERRUPT_CONTROLLER_CPU_INTERFACE_OFFSET));
    configASSERT(pxGICConfig->DistBaseAddress ==
        configINTERRUPT_CONTROLLER_BASE_ADDRESS);

    /* Install a default handler for each GIC interrupt. */
    xStatus =
        XScuGic_CfgInitialize(&xInterruptController, pxGICConfig,
        pxGICConfig->CpuBaseAddress);
    configASSERT(xStatus == XST_SUCCESS);
    (void) xStatus; /* Stop compiler warning if configASSERT() is undefined. */

    /* Initialise the LED port through GPIO driver. */
    pxConfigPtr = XGpioPs_LookupConfig(XPAR_XGPIOPS_0_DEVICE_ID);
    xStatus = XGpioPs_CfgInitialize(&xGpio, pxConfigPtr, pxConfigPtr->BaseAddr);
    configASSERT(xStatus == XST_SUCCESS);
    (void) xStatus; /* Stop compiler warning if configASSERT() is undefined. */

    /* Enable outputs and set low (initially turn-off the LED). */
    XGpioPs_SetDirectionPin(&xGpio, partstLED_OUTPUT, partstDIRECTION_OUTPUT);
    XGpioPs_SetOutputEnablePin(&xGpio, partstLED_OUTPUT, partstOUTPUT_ENABLED);
    XGpioPs_WritePin(&xGpio, partstLED_OUTPUT, 0x0);

    /* The Xilinx projects use a BSP that do not allow the start up code
       to be altered easily.  Therefore the vector table used by FreeRTOS
       is defined in FreeRTOS_asm_vectors.S, which is part of this project.
       Switch to use the FreeRTOS vector table. */
    vPortInstallFreeRTOSVectorTable();
}

/* ---------------------------------------------------------------------- */
/*  The following function is a thread that toggles LED on the ZedBoard.  */
/* --------------=------------------------------------------------------- */
void led_ctrl(void *pvParameters)
{
    TickType_t xNextWakeTime;
    int *pDone = (int *) pvParameters;

    xNextWakeTime = xTaskGetTickCount();

    while (! *pDone) /* app_done is false */
    {
        /* Wake up this task every second. */
        vTaskDelayUntil( &xNextWakeTime, configTICK_RATE_HZ);

        /*  Toggle the LED. */
        vToggleLED();
    }

    /* The thread has ended, we must delete this task from the task queue. */
    vTaskDelete(NULL);
}

/* ----------------------------------------------------------------- */
/*  The following functions are user-defined call-back routines      */
/*  for FreeRTOS. These functions are invoked by the FreeRTOS kernel */
/*  when things goes wrong.                                          */
/*                                                                   */
/*  Here, we only provide empty templates for these call-back funcs. */
/* ----------------------------------------------------------------- */

/* ----------------------------------------------------------------- */
void vApplicationMallocFailedHook(void)
{
    /*
       Called if a call to pvPortMalloc() fails because there is
       insufficient free memory available in the FreeRTOS heap.
       The size of the FreeRTOS heap is set by the configTOTAL_HEAP_SIZE
       configuration constant in FreeRTOSConfig.h.
     */
	xil_printf("STACK OVERFLOW!\n");
    taskDISABLE_INTERRUPTS();
    for (;;);
}

/* ----------------------------------------------------------------- */
void vApplicationStackOverflowHook(TaskHandle_t pxTask, char *pcTaskName)
{
    (void) pcTaskName;
    (void) pxTask;

    /* Run time stack overflow checking is performed if
       configCHECK_FOR_STACK_OVERFLOW is defined to 1 or 2.
       This hook function is called if a stack overflow is detected.
     */
    taskDISABLE_INTERRUPTS();
    for (;;);
}

/* ----------------------------------------------------------------- */
void vApplicationIdleHook(void)
{
    /* This is just a trivial example of an idle hook.
       It is called on each cycle of the idle task.  It must
       *NOT* block the processor.
     */
}

/* ----------------------------------------------------------------- */
void vApplicationTickHook(void)
{
	/* This function is called from the timer ISR. You can put
	   periodic maintenance operations here. However, the function
	   must be very short, not use much stack, and not call any
	   kernel API functions that don't end in "FromISR" or "FROM_ISR"
	 */
}

/* ----------------------------------------------------------------- */
void vAssertCalled(const char *pcFile, unsigned long ulLine)
{
    volatile unsigned long ul = 0;

    (void) pcFile;
    (void) ulLine;

    taskENTER_CRITICAL();
    {
        /* Set ul to a non-zero value using the debugger to step
           out of this function.
         */
        while (ul == 0)
        {
            portNOP();
        }
    }
    taskEXIT_CRITICAL();
}

/* ----------------------------------------------------------------- */
void vInitialiseTimerForRunTimeStats( void )
{
    XScuWdt_Config *pxWatchDogInstance;
    uint32_t ulValue;
    const uint32_t ulMaxDivisor = 0xff, ulDivisorShift = 0x08;

    pxWatchDogInstance = XScuWdt_LookupConfig( XPAR_SCUWDT_0_DEVICE_ID );
    XScuWdt_CfgInitialize( &xWatchDogInstance, pxWatchDogInstance, pxWatchDogInstance->BaseAddr );

    ulValue = XScuWdt_GetControlReg( &xWatchDogInstance );
    ulValue |= ulMaxDivisor << ulDivisorShift;
    XScuWdt_SetControlReg( &xWatchDogInstance, ulValue );

    XScuWdt_LoadWdt( &xWatchDogInstance, UINT_MAX );
    XScuWdt_SetTimerMode( &xWatchDogInstance );
    XScuWdt_Start( &xWatchDogInstance );
}

/* ----------------------------------------------------------------- */
/*  LED light control functions.                                     */
/* ----------------------------------------------------------------- */
void vSetLED(BaseType_t xValue)
{
    XGpioPs_WritePin(&xGpio, partstLED_OUTPUT, xValue);
}

void vToggleLED()
{
    BaseType_t xLEDState;

    xLEDState = XGpioPs_ReadPin(&xGpio, partstLED_OUTPUT);
    XGpioPs_WritePin(&xGpio, partstLED_OUTPUT, !xLEDState);
}
