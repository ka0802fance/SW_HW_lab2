/* ///////////////////////////////////////////////////////////////////// */
/*  File   : platform.c                                                  */
/*  Author : Chun-Jen Tsai                                               */
/*  Date   : 02/20/2016                                                  */
/* --------------------------------------------------------------------- */
/*  Some platform-dependent support routines for find_focus.c.           */
/* ///////////////////////////////////////////////////////////////////// */

#include "platform.h"
#include "xil_cache.h"
#include "xtime_l.h"

u32 FlashReadBaseAddress = 0;   /* This is necessary for file I/O routines */

/* Processor cache enable/disable functions */
void enable_caches()
{
    Xil_DCacheEnable();
    Xil_ICacheEnable();
}

void disable_caches()
{
    Xil_DCacheDisable();
    Xil_ICacheDisable();
}
