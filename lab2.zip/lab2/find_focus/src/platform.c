/* ///////////////////////////////////////////////////////////////////// */
/*  File   : platform.c                                                  */
/*  Author : Chun-Jen Tsai                                               */
/*  Date   : 02/20/2016                                                  */
/* --------------------------------------------------------------------- */
/*  Some platform-dependent support routines for find_focus.c.           */
/* ///////////////////////////////////////////////////////////////////// */

#include "platform.h"
#include "xil_cache.h"
#include "xtime_l.h"

u32 FlashReadBaseAddress = 0;   /* This is necessary for file I/O routines */

/* Processor cache enable/disable functions */
void enable_caches()
{
    Xil_DCacheEnable();
    Xil_ICacheEnable();
}

void disable_caches()
{
    Xil_DCacheDisable();
    Xil_ICacheDisable();
}

/* Microsecond-resolution timer function */

/* Global Timer is always clocked at half of the CPU frequency */
#define COUNTS_PER_USECOND  (XPAR_CPU_CORTEXA9_CORE_CLOCK_FREQ_HZ / 2000000)
#define FREQ_MHZ ((XPAR_CPU_CORTEXA9_CORE_CLOCK_FREQ_HZ+500000)/1000000)

long get_usec_time()
{
	XTime time_tick;

	XTime_GetTime(&time_tick);
	return (long) (time_tick / COUNTS_PER_USECOND);
}
