/* ///////////////////////////////////////////////////////////////////// */
/*  File   : find_focus.c                                                */
/*  Author : Chun-Jen Tsai                                               */
/*  Date   : 02/20/2016                                                  */
/* --------------------------------------------------------------------- */
/*  This program finds the image with the best focus in a sequence of    */
/*  8 JPEG images, 1.jpg, 2.jpg, ..., and 8.jpg, and then print out the  */
/*  the number of sharp edge pixels it detected in the sharpest image.   */
/* ///////////////////////////////////////////////////////////////////// */

#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#include "platform.h"
#include "nanojpeg.h"

#define N_IMAGES 8
typedef unsigned char uint8;

int  read_images_from_sdcard(uint8 *jpg[], unsigned long jpg_size[]);
int  jpeg_to_raw(uint8 *jpg[], unsigned long jpg_size[], uint8 *raw[], int *w, int *h);
void focus(uint8 *raw[], int w, int h, int *n, int *m);
int  edge_detection(uint8 *input, int width, int height);

uint8 *jpg_image[N_IMAGES];
uint8 *raw_image[N_IMAGES];
unsigned long jpg_size[N_IMAGES];

int main(int argc, char *argv[])
{
    int idx, code;
    int width, height, number, mark;
    long time_tick;

    /* Initialize image pointers */
    memset(jpg_image, 0, sizeof(jpg_image));
    memset(raw_image, 0, sizeof(raw_image));

    /* Read the image sequence from SD card. */
    printf("\n1) Reading the JPEG images from the SD card into memory: "); fflush(0);
    time_tick = get_usec_time();
    code = read_images_from_sdcard(jpg_image, jpg_size);
    time_tick = (get_usec_time() - time_tick + 500)/1000;
    printf("%ld msecs.\n", time_tick); fflush(0);
    if (code != 0)
    {
        printf("Error reading JPEG image #%d\n", code);
        goto clean_up_and_exit;
    }

    /* Decode the JPEG images into raw images. */
    printf("2) Decoding the JPEG images in memory: "); fflush(0);
    time_tick = get_usec_time();
    code = jpeg_to_raw(jpg_image, jpg_size, raw_image, &width, &height);
    time_tick = (get_usec_time() - time_tick + 500)/1000;
    printf("%ld msecs.\n", time_tick); fflush(0);
    if (code != 0)
    {
        printf("Error decoding JPEG image #%d.\n", code);
        goto clean_up_and_exit;
    }

    /* Begin locating the sharpest image. */
    printf("3) Locating the sharpest image in the sequence: "); fflush(0);
    time_tick = get_usec_time();
    focus(raw_image, width, height, &number, &mark);
    time_tick = (get_usec_time() - time_tick + 500)/1000;
    printf("%ld msecs.\n", time_tick); fflush(0);
    printf("\n=> Image %d is the sharpest one with %d edge points.\n\n", number, mark);
    code = 0;

    /* free allocated memory */
    clean_up_and_exit:
    for (idx = 0; idx < N_IMAGES; idx++)
    {
        if (jpg_image[idx] != NULL) free(jpg_image[idx]);
        if (raw_image[idx] != NULL) free(raw_image[idx]);
    }
    return code;
}

int read_images_from_sdcard(uint8 *jpg[], unsigned long size[])
{
    int idx;
    u32 fsize, status;
    uint8 *buf;
    char fname[32];

    /* We must disable cache or the SD card won't work. */
    disable_caches();

    for (idx = 0; idx < N_IMAGES; idx++)
    {
        sprintf(fname, "%d.jpg", idx+1);
        if (InitSD(fname, &fsize) != XST_SUCCESS)
        {
        	return idx+1;
        }
        else
        {
            size[idx] = fsize; /* save the size (in bytes) of the file 'fname' */
        	// printf("   Read file '%s', size = %lu bytes\n", fname, fsize);
        	if ((buf = malloc(fsize)) != NULL)
        	{
                /* Read the JPG image file into memory */
        		status = SDAccess(0, (u32) buf, fsize);
                ReleaseSD();
            	if (status != XST_SUCCESS)
            	{
            	    printf("File '%s' read error.\n", fname);
            	    return idx+1;
            	}
        	}
        	else
        	{
                printf("Cannot not allocate %lu bytes of memory!\n", fsize);
                return idx+1;
        	}
        }

        jpg[idx] = buf;
    }

    /* Re-enable caches for faster computations. */
    enable_caches();
    return 0;
}

int jpeg_to_raw(uint8 *jpg[], unsigned long jpg_size[], uint8 *raw[], int *width, int *height)
{
    int idx;

    for (idx = 0; idx < N_IMAGES; idx++)
    {
        /* Decode one JPEG image */
        // printf("   Decode image %d ... ", idx+1); fflush(0);
        njInit();
        if (njDecode(jpg[idx], jpg_size[idx]))
        {
            return idx+1;
        }

        if (njIsColor()) /* we do not allow color images */
        {
            return idx+1;
        }
        
        /* Save the decoded raw image */
        if ((raw[idx] = malloc(njGetImageSize())) == NULL)
        {
            return idx+1;
        }
        *width = njGetWidth(), *height = njGetHeight();
        memcpy(raw[idx], njGetImage(), njGetImageSize());
        njDone();
        // printf("done.\n");
    }

    return 0;
}

void focus(uint8 *raw[], int width, int height, int *number, int *mark)
{
    int idx;
    int sharpness;

    *mark = 0;
    for (idx = 0; idx < N_IMAGES; idx++)
    {
        sharpness = edge_detection(raw[idx], width, height);
        if (sharpness > *mark)
        {
            *mark = (int) sharpness;
            *number = idx+1;
        }
    }
}

/* 5x5 Edge detection masks: current patterns are for Sobel edge detector. */
const int hmask[5][5] = { /* horizontal edge detection mask */
        { 0,  0,  0,  0,  0},
        { 0,  1,  2,  1,  0},
        { 0,  0,  0,  0,  0},
        { 0, -1, -2, -1,  0},
        { 0,  0,  0,  0,  0}
};

const int vmask[5][5] = { /* vertical edge detection mask */
        {0,   0,  0,  0,  0},
        {0,  -1,  0,  1,  0},
        {0,  -2,  0,  2,  0},
        {0,  -1,  0,  1,  0},
        {0,   0,  0,  0,  0}
};

int edge_detection(uint8 *input, int width, int height)
/* ---------------------------------------------------------------- */
/*	Compute the number of edge points using a 5x5 mask operator.    */
/* ---------------------------------------------------------------- */
{
    int row, col, x, y, idx;
    int counter, hs, vs;

    counter = 0;
    for (row = 2; row < height-2; row++)
    {
        for (col = 2; col < width-2; col++)
        {
    		/* Compute the Sobel edge strength. */
            hs = vs = 0;
            idx = (row-2)*width + (col-2);
            for (y = -2; y <= 2; y++, idx += (width-5))
            {
            	for (x = -2; x <= 2; x++, idx++)
            	{
            		hs += input[idx]*hmask[y+2][x+2];
            		vs += input[idx]*vmask[y+2][x+2];
            	}
            }
            counter += (abs(hs) + abs(vs) > 128); /* (> 128) is an edge point */
        }
    }
    return counter;
}
