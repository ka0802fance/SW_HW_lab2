/* ///////////////////////////////////////////////////////////////////// */
/*  File   : platform.h                                                  */
/*  Author : Chun-Jen Tsai                                               */
/*  Date   : 02/20/2016                                                  */
/* --------------------------------------------------------------------- */
/*  Some platform-dependent support routines for find_focus.c.           */
/* ///////////////////////////////////////////////////////////////////// */

#include "xparameters.h"
#include "FileIo/fsbl.h"
#include "FileIo/sd.h"
#include "xstatus.h"

void enable_caches();
void disable_caches();
long get_usec_time();
